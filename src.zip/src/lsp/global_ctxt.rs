

pub struct GlobalCtxt {
    // all critical sections

    // callchain that contains conditioncal variable's wait in critical sections

    // callchain that contains channel's send/recv in critical section
}