use std::{collections::{HashMap, HashSet}, rc::Rc, cell::RefCell};

use log::info;
use rustc_hir::def_id::{LOCAL_CRATE, LocalDefId, DefId};
use rustc_middle::{ty::{TyCtxt, Ty, TyKind::FnDef}, mir::{Body, Local, Terminator, StatementKind, TerminatorKind}};

use crate::analysis::call_graph::analyze_callgraph;

use self::{ty::{Lifetimes, Lifetime}, lifetime::analyze_lifetimes, lock::parse_lockguard_type, call_graph::CallSite};


mod ty;
mod lifetime;
mod lock;
mod call_graph;

#[derive(Hash, Eq, PartialEq, Copy, Clone)]
pub enum CriticalSectionCall {
    ChSend,
    ChRecv,
    CondVarWait
}
pub struct CallInCriticalSection<'tcx> {
    // critical section lifetime
    cs_lifetime: Lifetime,
    // last call is the target call
    callchain: Vec<CallSite<'tcx>>
}
pub struct AnalysisResult<'tcx> {
    pub calls: Vec<CallInCriticalSection<'tcx>>,
    pub critical_sections: Vec<Lifetime>
}


pub fn filter_body_locals(body: &Body, filter: fn(Ty) -> bool) -> Vec<Local> {
    body.local_decls
    .iter_enumerated()
    .filter_map(|(local, decl)|{
        if filter(decl.ty) {
            return Some(local)
        } 

        None
    })
    .collect()
}

type CSCallFilter<'tcx> = dyn Fn(TyCtxt<'tcx>, &CallSite) -> bool;
type CSCallFilterSet<'tcx> = HashMap<CriticalSectionCall, &'tcx CSCallFilter<'tcx>>;

pub fn find_in_lifetime<'tcx, 'a>(tcx: TyCtxt<'tcx>, body: &'a Body<'tcx>, lt:&Lifetime, callgraph: &call_graph::CallGraph<'tcx>, cs_calls:& mut Vec<CallInCriticalSection<'tcx>>, callchains:Vec<CallSite<'tcx>>, filter_set:&CSCallFilterSet<'tcx>) {
    let callsites = &callgraph.callsites[&body.source.def_id()];
    for cs in callsites {
        let callee_id = cs.callee.def_id();
        let mut cs_call_type: Option<CriticalSectionCall> = None;
        for (t, f) in filter_set {
            if f(tcx, cs) {
                cs_call_type = Some(*t);
                break;
            }
        }
        // if callchain is 0, means it is not in the critical section yet
        if callchains.len() == 0 {
            for loc in &lt.live_locs {
                if cs.location != *loc {
                    continue
                }
                
                if cs_call_type != None {
                    // if this call is in critical section and is our interests
                    cs_calls.push(CallInCriticalSection{
                        cs_lifetime: lt.clone(),
                        callchain: Vec::new(),
                    })
                } else {
                    // if this call is not in critical section and is not our interests

                    let mut new_cc = callchains.clone();
                    new_cc.push(cs.clone());
                    let callee_body = tcx.optimized_mir(callee_id);
                    find_in_lifetime(tcx, callee_body, lt, callgraph, cs_calls, new_cc, filter_set)
                }
            }
        } else {
            let mut new_cc = callchains.clone();
            new_cc.push(cs.clone());
            if cs_call_type != None {
                // if this call is in critical section and is our interests
                cs_calls.push(CallInCriticalSection{
                    cs_lifetime: lt.clone(),
                    callchain: new_cc,
                })
            }
        }
        
    }
}


pub fn analyze(tcx: TyCtxt) -> Result<AnalysisResult, &'static str>  {
    info!("deadlock analyzing");
    let mut result = AnalysisResult {
        calls: Vec::new(),
        critical_sections: Vec::new(),
    };
    let fn_ids: Vec<LocalDefId> = tcx.mir_keys(())
    .iter()
    .filter(|id| {
        let hir = tcx.hir();
        hir.body_owner_kind(hir.local_def_id_to_hir_id(**id))
            .is_fn_or_closure()
    })
    .copied()
    .collect();

    info!("functions: {}", fn_ids.len());
    let lifetimes = Rc::new(RefCell::new(Lifetimes::new()));
    let mut callgraph = call_graph::CallGraph::new();
    fn_ids
    .clone()
    .into_iter()
    .for_each(|fn_id| {
        // println!("{:?}", fn_id);
        let body = tcx.optimized_mir(fn_id);
        analyze_lifetimes(tcx, body, lifetimes.clone());
        analyze_callgraph(tcx, body, &mut callgraph);
    });

    // fill critical section into result
    let mut all_lifetime:Vec<Lifetime> = (&lifetimes.borrow().body_local_lifetimes).values().into_iter().map(|hm|hm.values()).flatten().map(|l| l.clone()).collect();
    result.critical_sections.append(&mut all_lifetime);
    
    let mut filter_set: CSCallFilterSet = HashMap::new();

    filter_set.insert(CriticalSectionCall::ChSend, &|tcx, cs|{
        match cs.call_by_type {
            Some(caller_ty) => {
                let fname = tcx.item_name(cs.callee.def_id());
                let caller_ty_name = caller_ty.to_string();
                return caller_ty_name.contains("std::sync::mpsc::Sender") && fname.to_string() == "send";
            },
            None => false,
        }
    } );

    filter_set.insert(CriticalSectionCall::ChRecv, &|tcx, cs|{
        match cs.call_by_type {
            Some(caller_ty) => {
                let fname = tcx.item_name(cs.callee.def_id());
                let caller_ty_name = caller_ty.to_string();
                return caller_ty_name.contains("std::sync::mpsc::Receiver") && fname.to_string() == "recv";
            },
            None => false,
        }
    } );

    filter_set.insert(CriticalSectionCall::CondVarWait, &|tcx, cs|{
        match cs.call_by_type {
            Some(caller_ty) => {
                let fname = tcx.item_name(cs.callee.def_id());
                let caller_ty_name = caller_ty.to_string();
                return caller_ty_name.contains("std::sync::Condvar") && fname.to_string() == "wait";
            },
            None => false,
        }
    } );
    
    for (fn_id, local_lifetimes) in &lifetimes.borrow().body_local_lifetimes {
        let body = tcx.optimized_mir(*fn_id);
        let interested_locals = filter_body_locals(body, |ty| {
            match parse_lockguard_type(&ty) {
                Some(guard) => {
                    return true;
                },
                None => {},
            }
            false
        });

        for il in interested_locals {
            let lft = &local_lifetimes[&il];
            find_in_lifetime(tcx, body, lft, &callgraph, &mut result.calls, vec![], &filter_set);
        }


    }

    return Ok(result)
}
